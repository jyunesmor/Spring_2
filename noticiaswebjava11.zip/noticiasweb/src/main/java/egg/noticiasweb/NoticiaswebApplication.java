package egg.noticiasweb;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NoticiaswebApplication {

	public static void main(String[] args) {
		SpringApplication.run(NoticiaswebApplication.class, args);
	}

}
